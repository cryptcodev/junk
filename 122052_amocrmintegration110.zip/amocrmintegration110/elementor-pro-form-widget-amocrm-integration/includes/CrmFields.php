<?php
namespace Itgalaxy\Elementor\Form\AmoCrm\Integration\Includes;

class CrmFields
{
    public $leads;
    public $contacts;

    public function __construct()
    {
        $this->leads = [
            'name' => [
                'is_required' => true,
                'type' => esc_html__('String', 'el-pro-form-amocrm-integration'),
                'name' => esc_html__('Lead name', 'el-pro-form-amocrm-integration')
            ],
            // 'date_create'
            // 'last_modified'
            'status_id' => [
                'is_required' => false,
                'type' => esc_html__('Numeric', 'el-pro-form-amocrm-integration'),
                'name' => esc_html__('Pipeline / Status', 'el-pro-form-amocrm-integration')
            ],
            // 'pipeline_id'
            'price' => [
                'is_required' => false,
                'type' => esc_html__('Numeric', 'el-pro-form-amocrm-integration'),
                'name' => esc_html__('Deal budget', 'el-pro-form-amocrm-integration')
            ],
            'responsible_user_id' => [
                'is_required' => false,
                'type' => esc_html__('Numeric', 'el-pro-form-amocrm-integration'),
                'name' => esc_html__('Responsible (ID)', 'el-pro-form-amocrm-integration'),
                'description' => esc_html__(
                    'you can specify several, separated by commas, then the requests will be distributed sequentially',
                    'el-pro-form-amocrm-integration'
                )
            ],
            // 'request_id'
            // 'linked_company_id'
            'tags' => [
                'is_required' => false,
                'type' => esc_html__('String', 'el-pro-form-amocrm-integration'),
                'name' => esc_html__('Tags', 'el-pro-form-amocrm-integration')
            ]
            // 'visitor_uid'
        ];

        $this->contacts = [
            'name' => [
                'is_required' => true,
                'type' => esc_html__('String', 'el-pro-form-amocrm-integration'),
                'name' => esc_html__('Contact name', 'el-pro-form-amocrm-integration')
            ],
            // 'request_id'
            // 'date_create'
            // 'last_modified'
            'responsible_user_id' => [
                'is_required' => false,
                'type' => esc_html__('Numeric', 'el-pro-form-amocrm-integration'),
                'name' => esc_html__('Responsible (ID)', 'el-pro-form-amocrm-integration')
            ],
            // 'linked_leads_id'
            'company_name' => [
                'is_required' => false,
                'type' => esc_html__('String', 'el-pro-form-amocrm-integration'),
                'name' => esc_html__('Company name', 'el-pro-form-amocrm-integration')
            ],
            // 'linked_company_id'
            'tags' => [
                'is_required' => false,
                'type' => esc_html__('String', 'el-pro-form-amocrm-integration'),
                'name' => esc_html__('Tags', 'el-pro-form-amocrm-integration')
            ]
        ];

        $this->companies = [
            'name' => [
                'is_required' => true,
                'type' => esc_html__('String', 'el-pro-form-amocrm-integration'),
                'name' => esc_html__('Company name', 'el-pro-form-amocrm-integration')
            ],
            // 'request_id'
            // 'date_create'
            // 'last_modified'
            'responsible_user_id' => [
                'is_required' => false,
                'type' => esc_html__('Numeric', 'el-pro-form-amocrm-integration'),
                'name' => esc_html__('Responsible (ID)', 'el-pro-form-amocrm-integration')
            ],
            // 'linked_leads_id'
            // 'linked_company_id'
            'tags' => [
                'is_required' => false,
                'type' => esc_html__('String', 'el-pro-form-amocrm-integration'),
                'name' => esc_html__('Tags', 'el-pro-form-amocrm-integration')
            ]
        ];

        $this->task = [
            'text' => [
                'is_required' => true,
                'type' => esc_html__('String', 'el-pro-form-amocrm-integration'),
                'name' => esc_html__('Text', 'el-pro-form-amocrm-integration')
            ],
            // 'request_id'
            // 'date_create'
            // 'last_modified'
            'responsible_user_id' => [
                'is_required' => false,
                'type' => esc_html__('Numeric', 'el-pro-form-amocrm-integration'),
                'name' => esc_html__('Responsible (ID)', 'el-pro-form-amocrm-integration')
            ],
            // 'linked_leads_id'
            // 'linked_company_id'
            'type' => [
                'is_required' => false,
                'type' => esc_html__('String', 'el-pro-form-amocrm-integration'),
                'name' => esc_html__('Type', 'el-pro-form-amocrm-integration'),
                'options' => [
                    1 => esc_html__('Call', 'el-pro-form-amocrm-integration'),
                    2 => esc_html__('Meeting', 'el-pro-form-amocrm-integration')
                ]
            ],
            'complete_till_at' => [
                'is_required' => false,
                'type' => esc_html__('Numeric', 'el-pro-form-amocrm-integration'),
                'name' => esc_html__(
                    'Number of minutes for deadline',
                    'el-pro-form-amocrm-integration'
                ),
                'description' => esc_html__(
                    'after how many minutes after creation the task should be completed',
                    'el-pro-form-amocrm-integration'
                )
            ]
        ];
    }

    private function __clone()
    {
    }
}
