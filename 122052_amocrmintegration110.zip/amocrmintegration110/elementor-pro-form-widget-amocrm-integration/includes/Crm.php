<?php
namespace Itgalaxy\Elementor\Form\AmoCrm\Integration\Includes;

use AmoCRM\Client;
use AmoCRM\Exception;
use AmoCRM\Models\CustomField;
use AmoCRM\Models\Note;
use AmoCRM\Models\Task;

class Crm
{
    public static $analyticsFields = [
        'GA UTM',
        'UTM CONTENT'
    ];

    public static $amoAnalyticsFields = [
        'UTM_SOURCE',
        'UTM_MEDIUM',
        'UTM_CAMPAIGN',
        'UTM_TERM'
    ];

    public static function parseGoogleAnaliticsCookie()
    {
        if (!empty($_COOKIE[Bootstrap::UTM_COOKIES])) {
            return json_decode(wp_unslash($_COOKIE[Bootstrap::UTM_COOKIES]), true);
        }

        return [];
    }

    public static function addedGoogleAnaliticsInfoLead($lead)
    {
        $settings = get_option(Bootstrap::OPTIONS_KEY);

        if (!empty($settings['trackingId']) && !empty($_COOKIE['_ga'])) {
            $additionalFields = get_option(Bootstrap::OPTIONS_CUSTOM_FIELDS);
            $cookieFields = self::parseGoogleAnaliticsCookie();

            if (!empty($additionalFields['leads']) && is_array($additionalFields['leads'])) {
                foreach ($additionalFields['leads'] as $field) {
                    if ($field['name'] == 'GA UTM') {
                        $clientId = explode('.', wp_unslash($_COOKIE['_ga']));

                        $lead->addCustomField(
                            $field['id'],
                            wp_json_encode(
                                [
                                    'ga' => [
                                        'trackingId' => $settings['trackingId'],
                                        'clientId' => $clientId[2] . '.' . $clientId[3]
                                    ],
                                    'utm' => [
                                        'source' => !empty($cookieFields['utm_source'])
                                            ? $cookieFields['utm_source']
                                            : '',
                                        'medium' => !empty($cookieFields['utm_medium'])
                                            ? $cookieFields['utm_medium']
                                            : '',
                                        'content' => !empty($cookieFields['utm_content'])
                                            ? $cookieFields['utm_content']
                                            : '',
                                        'campaign' => !empty($cookieFields['utm_campaign'])
                                            ? $cookieFields['utm_campaign']
                                            : '',
                                        'term' => !empty($cookieFields['utm_term'])
                                            ? $cookieFields['utm_term']
                                            : ''
                                    ],
                                    'data_source' => 'form'
                                ]
                            )
                        );
                    }

                    if ($field['name'] == 'UTM CONTENT') {
                        $lead->addCustomField(
                            $field['id'],
                            !empty($cookieFields['utm_content']) ? $cookieFields['utm_content'] : ''
                        );
                    }

                    if (!empty($field['code'])) {
                        switch ($field['code']) {
                            case 'UTM_SOURCE':
                                $lead->addCustomField(
                                    $field['id'],
                                    !empty($cookieFields['utm_source']) ? $cookieFields['utm_source'] : ''
                                );
                                break;
                            case 'UTM_MEDIUM':
                                $lead->addCustomField(
                                    $field['id'],
                                    !empty($cookieFields['utm_medium']) ? $cookieFields['utm_medium'] : ''
                                );
                                break;
                            case 'UTM_CAMPAIGN':
                                $lead->addCustomField(
                                    $field['id'],
                                    !empty($cookieFields['utm_campaign']) ? $cookieFields['utm_campaign'] : ''
                                );
                                break;
                            case 'UTM_TERM':
                                $lead->addCustomField(
                                    $field['id'],
                                    !empty($cookieFields['utm_term']) ? $cookieFields['utm_term'] : ''
                                );
                                break;
                            default:
                                // Nothing
                                break;
                        }
                    }
                }
            }
        }

        return $lead;
    }

    public static function send($fields, $type, $contactForm)
    {
        $settings = get_option(Bootstrap::OPTIONS_KEY);
        $crmFields = new CrmFields();
        $additionalFields = get_option(Bootstrap::OPTIONS_CUSTOM_FIELDS);

        // prepare contact fields for search
        $prepareAdditionalContactFields = [];

        foreach ($additionalFields['contacts'] as $field) {
            $prepareAdditionalContactFields[$field['id']] = $field['code'];
        }

        // prepare company fields for search
        $prepareAdditionalCompanyFields = [];

        foreach ($additionalFields['companies'] as $field) {
            $prepareAdditionalCompanyFields[$field['id']] = $field['code'];
        }

        try {
            $amo = new Client($settings['domain'], $settings['login'], $settings['hash']);

            if ($type == 'contacts') {
                $entity = $amo->contact;

                $searchContactEmail = '';
                $searchContactPhone = '';

                foreach ($fields[$type] as $key => $value) {
                    if (in_array($key, array_keys($crmFields->{$type}))) {
                        if ($key == 'responsible_user_id') {
                            $value = self::resolveNextResponsible($value, 'contact', $contactForm);
                        }

                        $entity[$key] = $value;
                    } elseif ($key === 'custom_fields' && !empty($value) && is_array($value)) {
                        foreach ($value as $id => $val) {
                            if ($prepareAdditionalContactFields[$id] == 'EMAIL') {
                                $searchContactEmail = $val;
                            } elseif ($prepareAdditionalContactFields[$id] == 'PHONE') {
                                $searchContactPhone = $val;
                            }

                            $entity->addCustomField($id, $val, 'WORK');
                        }
                    }
                }

                $entity->setNotes(self::generateContactNote($amo, $fields));

                $existsContact = false;

                if ($searchContactEmail) {
                    $existsContact = $entity->apiList(['query' => $searchContactEmail]);
                }

                if (!$existsContact && $searchContactPhone) {
                    $existsContact = $entity->apiList(['query' => $searchContactPhone]);
                }

                // Exists contact is found
                if ($existsContact) {
                    $existsContact = current($existsContact);

                    $leadIds = [];

                    if (!empty($existsContact['linked_leads_id'])) {
                        $leadIds = array_merge($existsContact['linked_leads_id'], []);
                    }

                    $entity = $amo->contact;
                    $entity->setLinkedLeadsId($leadIds);
                    $entity->apiUpdate($existsContact['id']);
                } else {
                    $note = self::generateContactNote($amo, $fields);

                    if ($note) {
                        $entity->setNotes($note);
                    }

                    $amo->contact->apiAdd([$entity]);
                }
            } elseif ($type == 'leads') {
                $entity = $amo->lead;
                $entity = self::addedGoogleAnaliticsInfoLead($entity);

                // Set pipeline id
                if (isset($fields['leads']['status_id'])) {
                    $explodeCurrentStatus = explode('.', $fields['leads']['status_id']);

                    if (count($explodeCurrentStatus) > 1) {
                        $fields['leads']['pipeline_id'] = $explodeCurrentStatus[0];
                        $fields['leads']['status_id'] = $explodeCurrentStatus[1];
                    }
                }

                foreach ($fields['leads'] as $key => $value) {
                    if (in_array($key, array_keys($crmFields->{$type}))) {
                        if ($key == 'responsible_user_id') {
                            $value = self::resolveNextResponsible($value, 'lead', $contactForm);
                        }

                        $entity[$key] = $value;
                    } elseif ($key === 'custom_fields' && !empty($value) && is_array($value)) {
                        foreach ($value as $id => $val) {
                            $entity->addCustomField($id, $val);
                        }
                    }
                }

                Helper::log('lead entity', $entity);

                $leadID = $amo->lead->apiAdd([$entity]);

                // create task to deal
                if (!empty($fields['task']) && !empty($fields['task']['text'])) {
                    $taskFields = $fields['task'];

                    $task = $amo->task;

                    $task['element_id'] = $leadID;
                    $task['element_type'] = Task::TYPE_LEAD;
                    $task['task_type'] = !empty($taskFields['type']) ? $taskFields['type'] : 1; //Звонок

                    if (!empty($taskFields['responsible_user_id'])) {
                        $task['responsible_user_id'] = $taskFields['responsible_user_id'];
                    }

                    $completeCorrect = 3600;

                    if (!empty($taskFields['complete_till_at'])) {
                        $completeCorrect = (int) $taskFields['complete_till_at'] * 60;
                    }

                    $task->setCompleteTill(date('Y-m-d H:i', strtotime('+' . $completeCorrect . ' seconds')));
                    $task['text'] = $taskFields['text'];

                    Helper::log('task entity', $task);

                    $task->apiAdd();
                }

                $note = self::generateContactNote($amo, $fields);

                if ($note) {
                    $note['element_id'] = $leadID;
                    $note['element_type'] = Note::TYPE_LEAD;
                    $note->apiAdd();
                }

                $entity = $amo->contact;

                // create/find company
                if (!empty($fields['companies'])) {
                    $entityCompany = $amo->company;

                    $searchCompanyEmail = '';
                    $searchCompanyPhone = '';

                    foreach ($fields['companies'] as $key => $value) {
                        if (in_array($key, array_keys($crmFields->companies))) {
                            $entityCompany[$key] = $value;
                        } elseif ($key === 'custom_fields' && !empty($value) && is_array($value)) {
                            foreach ($value as $id => $val) {
                                if ($prepareAdditionalCompanyFields[$id] == 'EMAIL') {
                                    $searchCompanyEmail = $val;
                                } elseif ($prepareAdditionalCompanyFields[$id] == 'PHONE') {
                                    $searchCompanyPhone = $val;
                                }

                                $entityCompany->addCustomField($id, $val, 'WORK');
                            }
                        }
                    }

                    $existsCompany = false;

                    if ($searchCompanyEmail) {
                        $existsCompany = $amo->company->apiList(['query' => $searchCompanyEmail]);
                    }

                    if (!$existsCompany && $searchCompanyPhone) {
                        $existsCompany = $amo->company->apiList(['query' => $searchCompanyPhone]);
                    }

                    // Exists company is found
                    if ($existsCompany) {
                        $existsCompany = current($existsCompany);
                        $entity['linked_company_id'] = $existsCompany['id'];
                    } elseif (!empty($entityCompany['name'])) {
                        $companyId = $entityCompany->apiAdd();

                        if ($companyId) {
                            $entity['linked_company_id'] = $companyId;
                        }
                    }
                }

                $searchContactEmail = '';
                $searchContactPhone = '';

                foreach ($fields['contacts'] as $key => $value) {
                    if (in_array($key, array_keys($crmFields->{$type}))) {
                        if ($key == 'responsible_user_id') {
                            $value = self::resolveNextResponsible($value, 'contact', $contactForm);
                        }

                        $entity[$key] = $value;
                    } elseif ($key === 'custom_fields' && !empty($value) && is_array($value)) {
                        foreach ($value as $id => $val) {
                            if ($prepareAdditionalContactFields[$id] == 'EMAIL') {
                                $searchContactEmail = $val;
                            } elseif ($prepareAdditionalContactFields[$id] == 'PHONE') {
                                $searchContactPhone = $val;
                            }

                            $entity->addCustomField($id, $val, 'WORK');
                        }
                    }
                }

                $existsContact = false;

                if ($searchContactEmail) {
                    $existsContact = $amo->contact->apiList(['query' => $searchContactEmail]);
                }

                if (!$existsContact && $searchContactPhone) {
                    $existsContact = $amo->contact->apiList(['query' => $searchContactPhone]);
                }

                // Exists contact is found
                if ($existsContact) {
                    $existsContact = current($existsContact);
                    $leadIds = [$leadID];

                    if (!empty($existsContact['linked_leads_id'])) {
                        $leadIds = array_merge($existsContact['linked_leads_id'], $leadIds);
                    }

                    // if not enable update - just connect a new lead
                    if ((int) $updateContact !== 1) {
                        $entity = $amo->contact;
                    }

                    $entity->setLinkedLeadsId($leadIds);
                    $entity->apiUpdate($existsContact['id']);
                } else {
                    $entity->setLinkedLeadsId($leadID);

                    $amo->contact->apiAdd([$entity]);
                }
            } else {
                $unsorted = $amo->unsorted;
                $unsortedSourcedData = [];
                $lead = $amo->lead;
                $lead = self::addedGoogleAnaliticsInfoLead($lead);

                // Set pipeline id
                if (isset($fields['leads']['status_id'])) {
                    $explodeCurrentStatus = explode('.', $fields['leads']['status_id']);

                    if (count($explodeCurrentStatus) > 1) {
                        $unsorted['pipeline_id'] = $explodeCurrentStatus[0];
                    }
                }

                if (isset($fields['leads']['status_id'])) {
                    // Incoming leads not have status
                    unset($fields['leads']['status_id']);
                }

                foreach ($fields['leads'] as $key => $value) {
                    if (in_array($key, array_keys($crmFields->leads))) {
                        if ($key == 'responsible_user_id') {
                            $value = self::resolveNextResponsible($value, 'lead', $contactForm);
                        }

                        $lead[$key] = $value;
                        $unsortedSourcedData[$key . '_1'] = [
                            'type' => 'multitext',
                            'id' => $key,
                            'element_type' => '2',
                            'name' => $crmFields->leads[$key]['name'],
                            'value' => $value
                        ];
                    } elseif ($key === 'custom_fields' && !empty($value) && is_array($value)) {
                        foreach ($value as $id => $val) {
                            $lead->addCustomField($id, $val);

                            $name = '';

                            foreach ($additionalFields['leads'] as $field) {
                                if ($field['id'] == $id) {
                                    $name = $field['name'];
                                }
                            }

                            $unsortedSourcedData[$id . '_1'] = [
                                'type' => 'multitext',
                                'id' => $id,
                                'element_type' => '2',
                                'name' => $name,
                                'value' => $val
                            ];
                        }
                    }
                }

                $unsorted->addDataLead($lead);

                $contact = $amo->contact;

                foreach ($fields['contacts'] as $key => $value) {
                    if (in_array($key, array_keys($crmFields->contacts))) {
                        $contact[$key] = $value;
                        $unsortedSourcedData[$key . '_1'] = [
                            'type' => 'multitext',
                            'id' => $key,
                            'element_type' => '2',
                            'name' => $crmFields->contacts[$key]['name'],
                            'value' => $value
                        ];
                    } elseif ($key === 'custom_fields' && !empty($value) && is_array($value)) {
                        foreach ($value as $id => $val) {
                            $contact->addCustomField($id, $val, 'WORK');

                            $name = '';

                            foreach ($additionalFields['contacts'] as $field) {
                                if ($field['id'] == $id) {
                                    $name = $field['name'];
                                }
                            }

                            $unsortedSourcedData[$id . '_1'] = [
                                'type' => 'multitext',
                                'id' => $id,
                                'element_type' => '2',
                                'name' => $name,
                                'value' => $val
                            ];
                        }
                    }
                }

                $note = self::generateContactNote($amo, $fields);

                if ($note) {
                    $contact->setNotes($note);
                }

                $unsorted->addDataContact($contact);

                $unsorted['source'] = \get_home_url();

                $unsorted['source_data'] = [
                    'data' => $unsortedSourcedData,
                    'form_id' => $contactForm['id'],
                    'form_type' => 1,
                    'origin' => [
                        'ip' => isset($_SERVER['REMOTE_ADDR']) ? wp_unslash($_SERVER['REMOTE_ADDR']) : '',
                        'referer' => isset($_SERVER['HTTP_REFERER']) ? wp_unslash($_SERVER['HTTP_REFERER']) : ''
                    ],
                    'date' => time(),
                    'from' => \get_home_url(),
                    'form_name' => $contactForm['form_name']
                ];

                $unsorted->apiAddForms();
            }
        } catch (Exception $e) {
            Helper::log('error when amo request', $e, 'error');

            if (defined('WP_DEBUG') && WP_DEBUG === true) {
                printf(
                    'Error (%d): %s' . "\n",
                    (int) $e->getCode(),
                    esc_html($e->getMessage())
                );
            }
        }
    }

    public static function resolveNextResponsible($list, $type, $contactForm)
    {
        $list = explode(',', $list);

        if (count($list) === 1) {
            return $list[0];
        }

        if ($type === 'lead') {
            $last = get_post_meta($contactForm['id'], '_last_lead_responsible', true);
            $lastKey = array_search($last, $list);

            if (empty($last) || $lastKey === false || ($lastKey + 1) >= count($list)) {
                update_post_meta($contactForm['id'], '_last_lead_responsible', $list[0]);

                return $list[0];
            }

            update_post_meta($contactForm['id'], '_last_lead_responsible', $list[$lastKey + 1]);

            return $list[$lastKey + 1];
        } else {
            $last = get_post_meta($contactForm['id'], '_last_contact_responsible', true);
            $lastKey = array_search($last, $list);

            if (empty($last) || $lastKey === false || ($lastKey + 1) >= count($list)) {
                update_post_meta($contactForm['id'], '_last_contact_responsible', $list[0]);

                return $list[0];
            }

            update_post_meta($contactForm['id'], '_last_contact_responsible', $list[$lastKey + 1]);

            return $list[$lastKey + 1];
        }
    }

    public static function updateInformation()
    {
        $settings = get_option(Bootstrap::OPTIONS_KEY);

        try {
            $amo = new Client($settings['domain'], $settings['login'], $settings['hash']);

            if (!get_option('amocrm-elementor-ga-fields-is-added')) {
                foreach (self::$analyticsFields as $analyticsField) {
                    $field = $amo->custom_field;
                    $field['name'] = $analyticsField;
                    $field['type'] = CustomField::TYPE_TEXT;
                    $field['element_type'] = CustomField::ENTITY_LEAD;
                    $field['origin'] = uniqid() . '_elf';
                    $field->apiAdd();
                }

                update_option('amocrm-elementor-ga-fields-is-added', true);
            }

            $account = $amo->account->apiCurrent();

            update_option(Bootstrap::OPTIONS_USERS, $account['users']);
            update_option(Bootstrap::OPTIONS_LEADS_STATUSES, $account['leads_statuses']);
            update_option(Bootstrap::OPTIONS_CUSTOM_FIELDS, $account['custom_fields']);

            $pipelines = $amo->pipelines->apiList();
            update_option(Bootstrap::OPTIONS_PIPELINES, $pipelines);
        } catch (Exception $e) {
            Helper::log('error when amo request', $e, 'error');

            if (defined('WP_DEBUG') && WP_DEBUG === true) {
                printf(
                    'Error (%d): %s' . "\n",
                    (int) $e->getCode(),
                    esc_html($e->getMessage())
                );
            }
        }
    }

    public static function checkConnection()
    {
        $settings = get_option(Bootstrap::OPTIONS_KEY);

        try {
            $amo = new Client($settings['domain'], $settings['login'], $settings['hash']);
            $result = $amo->account->apiCurrent();
        } catch (Exception $e) {
            Helper::log('error when amo request', $e, 'error');

            // Clean failed information
            update_option(
                Bootstrap::OPTIONS_KEY,
                []
            );

            wp_die(
                sprintf(
                    esc_html__(
                        'Response amoCRM: Error code (%d): %s. Check the settings.',
                        'el-pro-form-amocrm-integration'
                    ),
                    (int) $e->getCode(),
                    esc_html($e->getMessage())
                ),
                esc_html__(
                    'An error occurred while verifying the connection to the amoCRM.',
                    'el-pro-form-amocrm-integration'
                ),
                [
                    'back_link' => true
                ]
            );
            // Escape ok
        }
    }

    public static function generateContactNote($amo, $fields)
    {
        // Generate note from contact
        $note = $amo->note;

        if (!empty($fields['note'])) {
            $note['text'] = $fields['note']
                . "\n"
                . esc_html__('Additional information about the sender:', 'el-pro-form-amocrm-integration')
                . "\n";
        } else {
            $note['text'] = esc_html__('Additional information about the sender:', 'el-pro-form-amocrm-integration')
                . "\n";
        }

        if (isset($_SERVER['REMOTE_ADDR'])) {
            $note['text'] .= esc_html__('IP-address: ', 'el-pro-form-amocrm-integration')
                . wp_unslash($_SERVER['REMOTE_ADDR'])
                . "\n";
        }

        if (isset($_SERVER['HTTP_USER_AGENT'])) {
            $note['text'] .= 'User Agent: '
                . wp_unslash($_SERVER['HTTP_USER_AGENT'])
                . "\n";
        }

        $note['text'] .= esc_html__('Date and time: ', 'el-pro-form-amocrm-integration')
            . date_i18n('Y-m-d H:i:s')
            . "\n";

        if (isset($_SERVER['HTTP_REFERER'])) {
            $note['text'] .= esc_html__('Referrer: ', 'el-pro-form-amocrm-integration')
                . wp_unslash($_SERVER['HTTP_REFERER'])
                . "\n";
        }

        // Set note type - is required
        $note['note_type'] = Note::COMMON;

        return $note;
    }

    private function __construct()
    {
    }

    private function __clone()
    {
    }
}
