<?php
namespace Itgalaxy\Elementor\Form\AmoCrm\Integration\Includes;

use ElementorPro\Modules\Forms\Classes\Action_Base;

class ActionAfterSubmit extends Action_Base
{
    public function get_name()
    {
        return 'itglx_amocrm';
    }

    public function get_tabs_name()
    {
        return $this->get_name() . '_tabs';
    }

    public function get_label()
    {
        return esc_html__('amoCRM', 'el-pro-form-amocrm-integration');
    }

    public function run($record, $ajax_handler)
    {
        $recordSettings = $record->get('form_settings');

        $type = isset($recordSettings['el_pro_amo_send_type']) ? $recordSettings['el_pro_amo_send_type'] : '';
        $type = in_array($type, Bootstrap::$sendTypes, true) ? $type : 'unsorted';

        $sendFields = [];
        $crmFields = new CrmFields();
        $additionalFields = get_option(Bootstrap::OPTIONS_CUSTOM_FIELDS);

        if ($type === 'contacts') {
            foreach ($crmFields->{$type} as $key => $_) {
                $value = isset($recordSettings['el_pro_amo_' . $type . '_' . $key])
                    ? $recordSettings['el_pro_amo_' . $type . '_' . $key]
                    : '';

                if ($value) {
                    $sendFields[$type][$key] = $record->replace_setting_shortcodes(trim($value));
                    $sendFields[$type][$key] = Helper::replaceAdditionalTags($sendFields[$type][$key]);
                }
            }

            if (!empty($additionalFields[$type]) && is_array($additionalFields[$type])) {
                foreach ($additionalFields[$type] as $field) {
                    $value = isset($recordSettings['el_pro_amo_' . $type . '_' . $field['id']])
                        ? $recordSettings['el_pro_amo_' . $type . '_' . $field['id']]
                        : '';

                    $value = $record->replace_setting_shortcodes(trim($value));
                    $value = Helper::replaceAdditionalTags($value);

                    if ($value) {
                        $sendFields[$type]['custom_fields'][$field['id']] = $value;
                    }
                }
            }
        } else {
            foreach (['contacts', 'companies', 'leads', 'task'] as $typeForeach) {
                foreach ($crmFields->{$typeForeach} as $key => $_) {
                    $value = isset($recordSettings['el_pro_amo_' . $typeForeach . '_' . $key])
                        ? $recordSettings['el_pro_amo_' . $typeForeach . '_' . $key]
                        : '';

                    $value = $record->replace_setting_shortcodes(trim($value));
                    $value = Helper::replaceAdditionalTags($value);

                    if ($value) {
                        $sendFields[$typeForeach][$key] = $value;
                    }
                }

                if (!empty($additionalFields[$typeForeach]) && is_array($additionalFields[$typeForeach])) {
                    foreach ($additionalFields[$typeForeach] as $field) {
                        $value = isset($recordSettings['el_pro_amo_' . $typeForeach . '_' . $field['id']])
                            ? $recordSettings['el_pro_amo_' . $typeForeach . '_' . $field['id']]
                            : '';

                        $value = $record->replace_setting_shortcodes(trim($value));
                        $value = Helper::replaceAdditionalTags($value);

                        if ($value) {
                            // is list
                            if (!in_array($field['code'], ['PHONE', 'EMAIL', 'IM'], true)
                                && !empty($field['enums'])
                            ) {
                                $ids = array_keys($field['enums']);
                                $labels = array_values($field['enums']);

                                $explodedField = explode(', ', $value);
                                $resolveValues = [];

                                foreach ($explodedField as $explodeValue) {
                                    if (array_search($explodeValue, $ids) !== false) {
                                        $resolveValues[] = $explodeValue;
                                    } elseif (array_search($explodeValue, $labels) !== false) {
                                        $resolveValues[] = $ids[array_search($explodeValue, $labels)];
                                    }
                                }

                                if ($resolveValues) {
                                    // type_id = 5 - multiselect
                                    $sendFields[$typeForeach]['custom_fields'][$field['id']]
                                        = (int) $field['type_id'] === 5
                                        ? $resolveValues
                                        : $resolveValues[0];
                                }
                            } else {
                                $sendFields[$typeForeach]['custom_fields'][$field['id']] = $value;
                            }
                        }
                    }
                }
            }
        }

        $note = isset($recordSettings['el_pro_amo_note']) ? trim($recordSettings['el_pro_amo_note']) : '';
        $note = $record->replace_setting_shortcodes(trim($note));
        $note = Helper::replaceAdditionalTags($note);

        if (!Helper::isVerify()) {
            if ($note) {
                $note = Helper::nonVerifyText()
                    . "\n"
                    . $note;
            } else {
                $note = Helper::nonVerifyText();
            }
        }

        if ($note) {
            $sendFields['note'] = $note;
        }

        if (!empty($sendFields)) {
            Crm::send($sendFields, $type, $record->get('form_settings'));
        }
    }

    public function register_settings_section($widget)
    {
        $additionalFields = get_option(Bootstrap::OPTIONS_CUSTOM_FIELDS);
        $crmFields = new CrmFields();

        $widget->start_controls_section(
            'section_' . $this->get_name(),
            [
                'label' => $this->get_label(),
                'condition' => [
                    'submit_actions' => $this->get_name()
                ]
            ]
        );

        $renderFields = new RenderFields();

        $renderFields->selectField(
            $widget,
            [
                'leads' => esc_html__(
                    'Lead (use tabs contact, company, lead and task)',
                    'el-pro-form-amocrm-integration'
                ),
                'contacts' => esc_html__('Contact', 'el-pro-form-amocrm-integration'),
                'unsorted' => esc_html__(
                    'Incoming Leads (use tabs contact and lead)',
                    'el-pro-form-amocrm-integration'
                )
            ],
            'send_type',
            esc_html__('Send type', 'el-pro-form-amocrm-integration'),
            [
                'is_required' => true,
                'description' => esc_html__(
                    'Choose the type of lead that will be generated in CRM',
                    'el-pro-form-amocrm-integration'
                ),
                'default' => 'leads',
                'disable_not_chosen' => true
            ]
        );

        $widget->start_controls_tabs($this->get_tabs_name());

        $tabsArray = [
            'leads' => esc_html__('Lead', 'el-pro-form-amocrm-integration'),
            'contacts' => esc_html__('Contact', 'el-pro-form-amocrm-integration'),
            'companies' => esc_html__('Company', 'el-pro-form-amocrm-integration'),
            'task' => esc_html__('Task', 'el-pro-form-amocrm-integration')
        ];

        foreach ($tabsArray as $tabKey => $tabLabel) {
            $widget->start_controls_tab(
                $this->get_tabs_name() . '_' . $tabKey . '_fields',
                [
                    'label' => $tabLabel
                ]
            );

            $renderFields = new RenderFields($tabKey . '_');

            foreach ($crmFields->$tabKey as $key => $field) {
                if ($key === 'status_id') {
                    $pipelines = get_option(Bootstrap::OPTIONS_PIPELINES);
                    $selectItems = [];

                    foreach ($pipelines as $pipelineID => $pipeline) {
                        if (empty($pipeline['statuses'])) {
                            continue;
                        }

                        foreach ($pipeline['statuses'] as $statusID => $status) {
                            // show only deal stages
                            if ($status['type'] !== 0) {
                                continue;
                            }

                            $selectItems[$pipelineID . '.' . $statusID] = $pipeline['label'] . ' - ' . $status['name'];
                        }
                    }

                    $renderFields->selectField(
                        $widget,
                        $selectItems,
                        $key,
                        $field['name'],
                        $field
                    );
                } elseif ($key === 'type') {
                    $renderFields->selectField(
                        $widget,
                        $field['options'],
                        $key,
                        $field['name'],
                        $field
                    );
                } else {
                    $renderFields->inputTextField(
                        $widget,
                        $key,
                        $field['name'],
                        $field
                    );
                }
            }

            if (!empty($additionalFields[$tabKey]) && is_array($additionalFields[$tabKey])) {
                foreach ($additionalFields[$tabKey] as $field) {
                    // Not show plugin created analytics fields
                    if (isset($field['name']) && in_array($field['name'], Crm::$analyticsFields)) {
                        continue;
                    }

                    // Not show amoCRM created analytics fields
                    if (isset($field['code']) && in_array($field['code'], Crm::$amoAnalyticsFields)) {
                        continue;
                    }

                    if (!empty($field['enums']) && !in_array($field['code'], ['PHONE', 'EMAIL', 'IM'])) {
                        $selectItems = [];

                        foreach ($field['enums'] as $value => $label) {
                            $selectItems[$value] = $label;
                        }

                        $renderFields->selectField(
                            $widget,
                            $selectItems,
                            $field['id'],
                            $field['name'],
                            $field
                        );
                    } else {
                        $renderFields->inputTextField(
                            $widget,
                            $field['id'],
                            $field['name'],
                            $field
                        );
                    }
                }
            }

            $widget->end_controls_tab();
        }

        $widget->end_controls_tabs();

        $renderFields = new RenderFields();

        $renderFields->textareaField(
            $widget,
            'note',
            esc_html__('Note text', 'el-pro-form-amocrm-integration'),
            [
                'is_required' => false,
                'description' => esc_html__(
                    'ip, user agent, date and time, referrer - added auto',
                    'el-pro-form-amocrm-integration'
                ),
                'separator' => 'before'
            ]
        );

        $widget->end_controls_section();
    }

    public function on_export($element)
    {
        // Nothing
    }
}
