<?php
namespace Itgalaxy\Elementor\Form\AmoCrm\Integration\Includes;

use Elementor\Controls_Manager;

class RenderFields
{
    public $namePrefix;

    public function __construct($prefix = '')
    {
        $this->namePrefix = $prefix;
    }

    public function selectField($widget, $list, $key, $title, $field)
    {
        if (in_array($key, ['status_id', 'type', 'send_type'], true)) {
            if (!isset($field['disable_not_chosen'])) {
                array_unshift($list, [esc_html__('Not chosen', 'el-pro-form-amocrm-integration')]);
            }

            $widget->add_control(
                'el_pro_amo_' . $this->namePrefix . $key,
                [
                    'label' => $title . ($field['is_required'] ? '<span style="color:red;"> * </span>' : ''),
                    'title' => 'key - ' . $key,
                    'required' => $field['is_required'],
                    'type' => Controls_Manager::SELECT,
                    'options' => (array) $list,
                    'default' => !empty($field['default']) ? $field['default'] : ''
                ]
            );
        } else {
            $widget->add_control(
                'el_pro_amo_' . $this->namePrefix . $key,
                [
                    'label' => $title . ($field['is_required'] ? '<span style="color:red;"> * </span>' : ''),
                    'title' => 'key - ' . $key,
                    'required' => isset($field['is_required']),
                    'type' => Controls_Manager::TEXT,
                    'description' => esc_html__('Possible values: ', 'el-pro-form-amocrm-integration')
                        . implode(', ', array_values($list))
                ]
            );
        }
    }

    public function inputTextField($widget, $key, $title, $field)
    {
        if ($key === 'responsible_user_id') {
            $users = get_option(Bootstrap::OPTIONS_USERS);
            $showUsers = [];

            foreach ($users as $user) {
                $showUsers[] = $user['id'] . ' - ' . $user['login'];
            }

            if (!empty($field['description'])) {
                $field['description'] .= '<br><br>'
                    . esc_html__('Users: ', 'el-pro-form-amocrm-integration')
                    . implode(', ', $showUsers);
            } else {
                $field['description'] = esc_html__('Users: ', 'el-pro-form-amocrm-integration')
                    . implode(', ', $showUsers);
            }
        }

        $widget->add_control(
            'el_pro_amo_' . $this->namePrefix . $key,
            [
                'label' => $title . ($field['is_required'] ? '<span style="color:red;"> * </span>' : ''),
                'title' => 'key - ' . $key,
                'required' => $field['is_required'],
                'type' => Controls_Manager::TEXT,
                'description' => isset($field['description']) ? $field['description'] : ''
            ]
        );
    }

    public function inputCheckboxField($widget, $key, $title, $field)
    {
        $widget->add_control(
            'el_pro_amo_' . $this->namePrefix . $key,
            [
                'label' => $title,
                'title' => 'key - ' . $key,
                'required' => $field['is_required'],
                'type' => Controls_Manager::SWITCHER,
                'default' => '',
                'description' => (isset($field['description']) ? $field['description'] : '')
            ]
        );
    }

    public function textareaField($widget, $key, $title, $field)
    {
        $widget->add_control(
            'el_pro_amo_' . $this->namePrefix . $key,
            [
                'label' => $title . ($field['is_required'] ? '<span style="color:red;"> * </span>' : ''),
                'title' => 'key - ' . $key,
                'required' => $field['is_required'],
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'separator' => isset($field['separator']) ? $field['separator'] : '',
                'description' => (isset($field['description']) ? $field['description'] : '')
            ]
        );
    }
}
