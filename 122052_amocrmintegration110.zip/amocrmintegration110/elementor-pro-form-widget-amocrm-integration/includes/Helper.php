<?php
namespace Itgalaxy\Elementor\Form\AmoCrm\Integration\Includes;

use Monolog\Handler\StreamHandler;
use Monolog\Logger;

class Helper
{
    public static $log;

    public static function log($message, $data = [], $type = 'info')
    {
        $settings = get_option(Bootstrap::OPTIONS_KEY);
        $enableLogging = isset($settings['enabled_logging']) && (int) $settings['enabled_logging'] === 1;

        if ($enableLogging) {
            try {
                if (empty(self::$log)) {
                    self::$log = new Logger('elproamo');
                    self::$log->pushHandler(
                        new StreamHandler(EL_PRO_FORM_AMOCRM_PLUGIN_DIR . 'logs/.elproamo.log', Logger::INFO)
                    );
                }

                self::$log->$type($message, (array) $data);
            } catch (\Exception $exception) {
                if (is_super_admin()) {
                    wp_die(
                        sprintf(
                            esc_html__(
                                'Error code (%s): %s.',
                                'el-pro-form-amocrm-integration'
                            ),
                            $exception->getCode(),
                            $exception->getMessage()
                        ),
                        esc_html__(
                            'An error occurred while writing the log file.',
                            'el-pro-form-amocrm-integration'
                        ),
                        [
                            'back_link' => true
                        ]
                    );
                    // escape ok
                }
            }
        }
    }

    public static function isVerify()
    {
        $value = get_site_option(Bootstrap::PURCHASE_CODE_OPTIONS_KEY);

        if (!empty($value)) {
            return true;
        }

        return false;
    }

    public static function nonVerifyText()
    {
        return esc_html__(
                'Please verify the purchase code on the plugin integration settings page - ',
                'el-pro-form-amocrm-integration'
            )
            . admin_url()
            . 'admin.php?page=elementor-amocrm-integration-settings';
    }

    public static function replaceAdditionalTags($value)
    {
        $replaceArray = [
            '[utm_source]' => '',
            '[utm_medium]' => '',
            '[utm_campaign]' => '',
            '[utm_term]' => '',
            '[utm_content]' => '',
            '[roistat_visit]' => isset($_COOKIE['roistat_visit'])
                ? $_COOKIE['roistat_visit']
                : '',
            '[gaClientID]' => ''
        ];

        if (!empty($_COOKIE['_ga'])) {
            $clientId = explode('.', wp_unslash($_COOKIE['_ga']));
            $replaceArray['[gaClientID]'] = $clientId[2] . '.' . $clientId[3];
        }

        if (!empty($_COOKIE[Bootstrap::UTM_COOKIES])) {
            $utmParams = json_decode(wp_unslash($_COOKIE[Bootstrap::UTM_COOKIES]), true);

            foreach ($utmParams as $key => $valueUtm) {
                $replaceArray['[' . $key . ']'] = rawurldecode(wp_unslash($valueUtm));
            }
        }

        $value = str_replace(array_keys($replaceArray), array_values($replaceArray), $value);

        return $value;
    }

    private function __construct()
    {
        // Nothing
    }

    private function __clone()
    {
        // Nothing
    }
}
