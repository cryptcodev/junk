=== Elementor Pro Form Widget - amoCRM - Integration ===
Contributors: https://codecanyon.net/user/itgalaxycompany
Tags: amocrm crm, amocrm deals, business amocrm, elementor pro form, elementor pro form amocrm, form, integration, deal finder, deal management, deal scraper, deals, marketing deals, sales deals.

== Description ==

The main task of this plugin is a send your `Elementor Pro Form Widget` forms directly to your amoCRM account.

= Features =

* Integrate your `Elementor Pro Form Widget` forms with amoCRM;
* Integrate unlimited `Elementor Pro Form Widget` forms;
* You can choice that your want to generate - lead, incoming lead or contact;
* You can set up each form personally, specify which information you want to get;
* Creation of the lead, occurs together with the creation / binding (used existing if there is) of the contact and company. (if their fields are filled);
* Support creating task to lead;
* Custom fields are loaded from the CRM;
* Supports for `utm` params in `URL` to use;
* Supports for sending `GA Client ID`;
* Supports for sending `roistat_visit`;
* Multiple pipeline support;
* Image previews;
* Super easy to set-up;

== Installation ==

1. Extract `elementor-pro-form-widget-amocrm-integration.zip` and upload it to your `WordPress` plugin directory
(usually /wp-content/plugins ), or upload the zip file directly from the WordPress plugins page.
Once completed, visit your plugins page.
2. Be sure `Elementor Pro` Plugin is enabled.
3. Activate the plugin through the `Plugins` menu in WordPress.
4. Go to the `Elementor` -> `amoCRM`.
5. Enter the domain name of your account `amoCRM` (without schema, i.e. http:// or https://).
6. Enter the login of your account `amoCRM`. Your should have permissions to adding contacts and deals in `amoCRM`.
7. Enter the API key. Your can find it on the settings page `amoCRM` account (your_amoCRM_domain/settings/profile/).
8. (ONLY FOR DEALS) If your use Google Analytics for monitoring your statistics, your can get more data.
Enter the Google Analytics Tracking ID.
Add send data in AmoCRM. (your_amoCRM_domain/settings/pipeline/leads/)
9. Save settings.
10. When editing forms you can add the `Actions After Submit` section several new action `amoCRM`.

== Changelog ==

= 1.1.0 =
Feature: reset fields cache by button without cron.

= 1.0.2 =
Chore: use composer autoloader.
Chore: show only deal stages in select.

= 1.0.0 =
Initial public release
