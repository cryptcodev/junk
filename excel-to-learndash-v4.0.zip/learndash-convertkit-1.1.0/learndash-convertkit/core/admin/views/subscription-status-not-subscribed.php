<?php
/**
 * Shows user subscription status when not subscribed.
 *
 * @since 1.1.0
 *
 * @var array $subscriber
 */

defined( 'ABSPATH' ) || die();
?>

<div class="ld-convertkit-user-subscription-status">

    <table class="form-table">
        <tr>
            <th>
				<?php _e( 'LearnDash ConvertKit Subscription', 'learndash-convertkit' ); ?>
            </th>

            <td>
                <span class="ld-convertkit-subscription-status ld-convertkit-subscription-status-not-subscribed">
                    <?php _e( 'Not Subscribed', 'learndash-convertkit' ); ?>
                </span>
            </td>
        </tr>
    </table>

</div>