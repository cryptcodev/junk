<?php
if( $meta['icon'] ) echo '<b class="m-lds-item-icon"><i class="fa ' . esc_attr( $meta['icon'] ) . '"></i></b>&nbsp;'; ?>
