<?php
/**
 *  .ld-lesson-topic-list .ld-table-list-items .ld-table-list-item {
                  border: 2px solid #e2e7ed;
                  border-radius: 6px;
 */
