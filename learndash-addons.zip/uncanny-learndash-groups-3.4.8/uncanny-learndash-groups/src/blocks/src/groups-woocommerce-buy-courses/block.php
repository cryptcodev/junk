<?php

/**
 * Register Groups Reports Inerface
 * render it with a callback function
 */

register_block_type( 'uncanny-learndash-groups/uo-groups-buy-courses', [
	'attributes'      => [],
	'render_callback' => 'render_uo_buy_courses_func',
] );

function render_uo_buy_courses_func() {

	// Start output
	ob_start();

	// Check if the class exists
	if ( class_exists( '\uncanny_learndash_groups\WoocommerceBuyCourses' ) ) {

		$class = \uncanny_learndash_groups\Utilities::get_class_instance( 'WoocommerceBuyCourses' );
		// Check if the course ID is empty
		echo $class->uo_buy_courses_func();
	}

	// Get output
	$output = ob_get_clean();

	// Return output
	return $output;
}
