(function ($) {
	$(function () {
		//var url = ajax_url.url + "?action=search_user&name=" + $('#ulgm_group_leader_email').val();
		if ( $("#ulgm_group_leader_email").length > 0 ){
			var url = ajax_url.url + "?action=search_user";
			$("#ulgm_group_leader_email").autocomplete({
				source: url,
				delay: 500,
				minLength: 3
			});
		}
	});

})(jQuery);

/*jQuery(document).ready(function ($) {
 var data = {
 'action': 'search_user',
 'name': jQuery("#ulgm_group_leader_email").val()
 };
 // We can also pass the url value separately from ajaxurl for front end AJAX implementations
 jQuery.post(ajax_url.url, data, function (response) {
 alert('Got this from the server: ' + response);
 });

 jQuery("#ulgm_group_leader_email").autocomplete({
 source: ajax_url.url,
 delay: 500,
 minLength: 3
 });
 });*/
