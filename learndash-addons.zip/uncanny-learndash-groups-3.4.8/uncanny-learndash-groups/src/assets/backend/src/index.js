import './js/learndash_woocommerce.js';
import './js/uo-admin-forms.js';
import './js/user-email-autocomplete.js';
import './js/woocommerce.js';
import './js/ulgm-rest-forms.js';

import './scss/main.scss';

// Do on DOM ready
document.addEventListener( 'DOMContentLoaded', () => {});