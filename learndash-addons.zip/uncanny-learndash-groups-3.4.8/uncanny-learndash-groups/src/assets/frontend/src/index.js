import './js/define-main-object.js';

import './js/ulgm-rest-forms.js';
import './js/ulgm-assignments.js';
import './js/ulgm-essays.js';
import './js/ulgm-management.js';
import './js/ulgm-reporting.js';
import './js/front.js';
import './js/learndash_template_script.js';
import './js/uncanny-owl-groups-ui.js';

import CourseDashboard from './js/course-dashboard.js';
import ManageProgress from './js/manage-progress.js';

import './scss/main.scss';

// Do on DOM ready
document.addEventListener( 'DOMContentLoaded', () => {
	new CourseDashboard();
	new ManageProgress();
});